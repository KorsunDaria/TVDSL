# HW5. Темпоральные спецификации и проверка моделей

**Модель:** протокол запрос–ответ (Req/Ack) с возможной потерей запроса и тайм-аутом клиента, порог `T = 3`.
**Инструменты:** NuSMV 2.7.1 (LTL + CTL), Spin 6.5.2 (те же 5 LTL-свойств). Python — независимая проверка графа состояний.

## Состав

| Файл | Назначение |
|---|---|
| `model/reqack.smv` | модель NuSMV: 5 LTL (S1–S3, L1, L2), CTL P6 + вспомогательные C1, C2 |
| `model/reqack.pml` | модель Promela, 5 LTL-свойств |
| `tools/verify.py` | явный перебор состояний, свидетельства для CTL |
| `tools/run_checks.py` | автозапуск всех проверок, замер времени и памяти |
| `logs/` | логи запусков и `summary.md` |
| `REPORT.md` | отчёт |

## Запуск

Нужны `python3`, `NuSMV`, `spin`, `gcc` в `PATH`. Из корня проекта:

```bash
python3 tools/run_checks.py
```

Скрипт запускает NuSMV (BDD), Spin (POR, без POR, bitstate) и Python-проверку, пишет логи в `logs/` и сводку в `logs/summary.md`. Отсутствующий инструмент пропускается.

Вручную:

```bash
NuSMV model/reqack.smv
cd model && spin -a reqack.pml && gcc -O2 -o pan pan.c && ./pan -a -N s1   # s1 s2 s3 l1 l2
python3 tools/verify.py
```
